"""Safe synthetic swarm lab: adaptive strategy stress testing + social market simulation."""
import os
import streamlit as st

from algobot import ui
from algobot.config import ConfigError, load_config, validate_config
from algobot.synthetic_swarm import PERSONAS, SAFE_WEB_PAGES, run_swarm, plan_journey
from algobot.mirofish_sim import agent_chat, run_mirofish
from algobot.agent_research import run_agent_research, run_real_data_research
from algobot.mirofish_qa import build_strategy_evidence, run_website_swarm
from algobot.live_data import INTERVALS, MARKETS, fetch_ohlc, LiveDataError

ui.setup("Swarm Simulation Lab", "🧬")
ui.header(
    "Swarm Simulation Lab",
    "Adaptive agents, social debate, memory, knowledge graph and safe website journeys.",
    mode="research:Swarm only",
)
st.info(
    "Safety boundary: everything here is synthetic. Agents cannot place live orders, "
    "access broker credentials, or reach OpenAlgo."
)

raw = st.session_state.get("last_raw")
try:
    if raw is not None:
        cfg = validate_config(raw)
        st.success("Using the strategy from your latest Backtest.")
    else:
        demo = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "configs",
            "demo_rules.yaml",
        )
        cfg = load_config(demo)
        st.caption("Using the demo strategy. Run a Backtest first to test your own strategy.")
except ConfigError as exc:
    st.error(f"The settings are not valid: {exc}")
    st.stop()

st.markdown("## 1. Adaptive strategy swarm")
a, b, c = st.columns(3)
agent_count = a.slider("Synthetic agents", 2, 32, 8)
rounds = b.slider("Adaptive rounds", 1, 12, 4)
days = c.slider("Days per round", 2, 20, 8)

if st.button("🧬 Run adaptive strategy swarm", type="primary", width="stretch"):
    with st.spinner("Running agents through changing synthetic worlds…"):
        st.session_state["swarm_report"] = run_swarm(
            cfg, agents=agent_count, rounds=rounds, days_per_round=days, seed=700
        )

report = st.session_state.get("swarm_report")
if report:
    x, y, z, w = st.columns(4)
    x.metric("Agent episodes", report.episodes)
    y.metric("Average P&L", f"₹{report.mean_pnl:,.0f}")
    z.metric("Profitable episodes", f"{report.profitable_pct:.0f}%")
    w.metric("Risk failures", report.risk_failures)
    st.dataframe(
        [
            {
                "agent": ag.id,
                "persona": ag.persona.name,
                "score": round(ag.score, 3),
                "strategy belief": round(ag.memory.beliefs["strategy_quality"], 3),
                "risk belief": round(ag.memory.beliefs["risk_safety"], 3),
                "trend belief": round(ag.memory.beliefs["trend_preference"], 3),
                "rounds remembered": len(ag.memory.observations),
            }
            for ag in report.agents
        ],
        width="stretch",
        hide_index=True,
    )
    if report.failure_modes:
        st.warning("Swarm findings: " + "; ".join(report.failure_modes))
    else:
        st.success("No swarm-level failure mode was detected in this bounded experiment.")

st.markdown("## 2. Social market simulation")
st.caption(
    "This layer adds a synthetic event/news world, agent-to-agent debate, persistent memory, "
    "influence edges and a local knowledge graph. It is independent of live execution."
)
d, e, f = st.columns(3)
social_agents = d.slider("Social agents", 2, 24, 8, key="social_agents")
ticks = e.slider("Simulation ticks", 4, 60, 24, key="social_ticks")
strategy_score = f.slider("Strategy evidence", 0.0, 1.0, 0.50, 0.05, key="strategy_evidence")
risk_score = st.slider("Risk evidence", 0.0, 1.0, 0.50, 0.05, key="risk_evidence")

if st.button("🌐 Run social market world", type="primary", width="stretch"):
    with st.spinner("Agents are reading synthetic events, debating and updating memory…"):
        st.session_state["mirofish_result"] = run_mirofish(
            agents=social_agents,
            ticks=ticks,
            seed=700,
            strategy_score=strategy_score,
            risk_score=risk_score,
        )

mf = st.session_state.get("mirofish_result")
if mf:
    social_report, social_cohort, social_messages, social_graph, social_events = mf
    x, y, z, w = st.columns(4)
    x.metric("Events", social_report.events)
    y.metric("Agent messages", social_report.messages)
    z.metric("Graph nodes", social_report.graph_nodes)
    w.metric("Graph edges", social_report.graph_edges)

    st.markdown("### Collective belief")
    q, r, s = st.columns(3)
    q.metric("Consensus", f"{social_report.consensus:+.2f}")
    r.metric("Consensus strength", f"{social_report.consensus_strength:.2f}")
    s.metric("Mean strategy belief", f"{social_report.mean_strategy_belief:.2f}")

    st.markdown("### Agent state + memory")
    st.dataframe(
        [
            {
                "agent": ag.agent_id,
                "role": ag.persona.role,
                "stance": round(ag.stance, 2),
                "sim P&L": round(ag.pnl, 2),
                "strategy belief": round(ag.memory.beliefs["strategy_quality"], 2),
                "risk belief": round(ag.memory.beliefs["risk_safety"], 2),
                "memories": len(ag.memory.observations),
                "messages": ag.messages,
            }
            for ag in social_cohort
        ],
        width="stretch",
        hide_index=True,
    )

    with st.expander("Recent synthetic debate", expanded=False):
        st.dataframe(
            [
                {
                    "tick": m.tick,
                    "sender": m.sender,
                    "recipient": m.recipient,
                    "stance": round(m.stance, 2),
                    "message": m.text,
                }
                for m in social_messages[-30:]
            ],
            width="stretch",
            hide_index=True,
        )

    st.markdown("### Post-simulation agent chat")
    selected = st.selectbox(
        "Choose an agent",
        options=[ag.agent_id for ag in social_cohort],
        key="chat_agent",
    )
    question = st.text_input(
        "Ask the simulated agent about its evidence, risk view or disagreement",
        placeholder="Why did you become bullish?",
        key="chat_question",
    )
    if st.button("💬 Ask agent", key="ask_agent"):
        selected_agent = next(ag for ag in social_cohort if ag.agent_id == selected)
        st.write(agent_chat(selected_agent, question, social_graph))

    if social_report.failure_modes:
        st.warning("Simulation findings: " + "; ".join(social_report.failure_modes))
    st.markdown("### Research report")
    for finding in social_report.key_findings:
        st.write("• " + finding)

st.markdown("## 3. Autonomous research agents")
st.caption(
    "These agents do the actual research work: generate bounded strategy mutations, "
    "run them across synthetic Indian-market regimes, critique failures, keep survivors, "
    "and validate the finalists on an untouched holdout world. No live orders."
)
g1, g2, g3 = st.columns(3)
research_generations = g1.slider("Research generations", 1, 8, 4, key="research_generations")
research_per_agent = g2.slider("Candidates per agent", 1, 4, 2, key="research_per_agent")
research_days = g3.slider("Synthetic days / world", 2, 15, 8, key="research_days")

if st.button("🤖 Let agents do the research", type="primary", width="stretch"):
    with st.spinner("Agents are generating, testing, rejecting and mutating strategies…"):
        st.session_state["agent_research"] = run_agent_research(
            cfg,
            generations=research_generations,
            candidates_per_agent=research_per_agent,
            days=research_days,
            seed=1701,
        )

ar = st.session_state.get("agent_research")
if ar:
    a1, a2, a3, a4 = st.columns(4)
    a1.metric("Candidates tested", ar.candidates_tested)
    a2.metric("Generations", ar.generations)
    a3.metric("Winner", ar.winner_id or "None")
    a4.metric("Verdict", ar.verdict)
    st.dataframe(
        [
            {
                "candidate": s.candidate_id,
                "gen": s.generation,
                "train P&L": round(s.train_pnl, 2),
                "holdout P&L": round(s.holdout_pnl, 2),
                "train PF": round(s.train_pf, 2),
                "holdout PF": round(s.holdout_pf, 2),
                "holdout DD": round(s.holdout_dd, 2),
                "robustness": round(s.robustness, 3),
                "accepted": s.accepted,
                "reasons": "; ".join(s.reasons),
            }
            for s in sorted(ar.scores, key=lambda x: x.robustness, reverse=True)[:30]
        ],
        width="stretch",
        hide_index=True,
    )
    for finding in ar.findings:
        st.write("• " + finding)
    if ar.winner_cfg:
        st.success(
            "Agents produced a research candidate, but it is NOT cleared for live trading. "
            "Run it on real out-of-sample Indian data and the Reality Check before considering paper trading."
        )

st.markdown("## 3b. Real Indian-market agent research")
st.caption(
    "This is the serious lane: agents work on downloaded historical OHLCV, split it into "
    "earlier training data and a later untouched holdout, and compete to find an edge. "
    "Data is research-only; no orders or broker execution are reachable."
)
rc1, rc2, rc3 = st.columns(3)
real_market = rc1.selectbox("Indian market", ["Nifty 50", "Bank Nifty", "Nifty IT"], key="real_agent_market")
real_interval = rc2.selectbox(
    "Historical timeframe", ["15 minutes", "1 hour", "1 day"], index=0, key="real_agent_interval"
)
real_generations = rc3.slider("Real-data generations", 1, 6, 3, key="real_agent_generations")
if st.button("🧪 Let agents attack real Indian history", type="primary", width="stretch"):
    try:
        with st.spinner("Downloading historical OHLCV and letting the agents research it…"):
            ticker = MARKETS[real_market]
            interval, period = INTERVALS[real_interval]
            real_prices = fetch_ohlc(ticker, interval, period)
            st.session_state["real_agent_research"] = run_real_data_research(
                cfg, real_prices, generations=real_generations, candidates_per_agent=2
            )
            st.session_state["real_agent_bars"] = len(real_prices)
            st.session_state["real_agent_range"] = (
                str(real_prices.index.min()), str(real_prices.index.max())
            )
    except (LiveDataError, ValueError, KeyError) as exc:
        st.error(f"Real-data agent research could not run: {exc}")

rar = st.session_state.get("real_agent_research")
if rar:
    rr1, rr2, rr3, rr4 = st.columns(4)
    rr1.metric("Real candidates", rar.candidates_tested)
    rr2.metric("Bars tested", st.session_state.get("real_agent_bars", "—"))
    rr3.metric("Winner", rar.winner_id or "None")
    rr4.metric("Verdict", rar.verdict)
    date_range = st.session_state.get("real_agent_range")
    if date_range:
        st.caption(f"Historical window: {date_range[0]} → {date_range[1]}")
    st.dataframe(
        [{
            "candidate": s.candidate_id,
            "gen": s.generation,
            "train P&L": round(s.train_pnl, 2),
            "OOS P&L": round(s.holdout_pnl, 2),
            "train PF": round(s.train_pf, 2),
            "OOS PF": round(s.holdout_pf, 2),
            "OOS DD": round(s.holdout_dd, 2),
            "accepted": s.accepted,
            "why rejected": "; ".join(s.reasons),
        } for s in sorted(rar.scores, key=lambda x: x.robustness, reverse=True)[:30]],
        width="stretch", hide_index=True,
    )
    for finding in rar.findings:
        st.write("• " + finding)

st.markdown("## 4. Full MiroFish adversarial run")
st.caption(
    "This combines independent regime evidence with synthetic personas, memory/graph-style "
    "aggregation and an adversarial verdict. It is deliberately hostile to the strategy: "
    "a positive result is a research signal, not a profit guarantee."
)
mf_rounds = st.slider("Adversarial evidence rounds", 6, 36, 12, key="mf_full_rounds")
mf_days = st.slider("Days per synthetic regime", 2, 15, 8, key="mf_full_days")
if st.button("🧠 Run full MiroFish strategy attack", type="primary", width="stretch"):
    with st.spinner("Agents are challenging the strategy across independent regimes…"):
        st.session_state["full_mirofish_strategy"] = build_strategy_evidence(
            cfg, rounds=mf_rounds, days=mf_days, seed=9001
        )

full_mf = st.session_state.get("full_mirofish_strategy")
if full_mf:
    x, y, z, w = st.columns(4)
    x.metric("Regime evidence", len(full_mf.evidence))
    y.metric("Profitable regimes", f"{full_mf.profitable_rate:.0f}%")
    z.metric("Mean PF", f"{full_mf.mean_profit_factor:.2f}")
    w.metric("Verdict", full_mf.verdict)
    st.dataframe(
        [{
            "regime": e.regime,
            "P&L": round(e.pnl, 2),
            "trades": e.trades,
            "PF": round(e.profit_factor, 2),
            "DD": round(e.drawdown, 2),
            "passed": e.passed,
        } for e in full_mf.evidence],
        width="stretch", hide_index=True,
    )
    st.caption(
        f"Consensus {full_mf.consensus:+.2f} · strength {full_mf.consensus_strength:.2f} · "
        f"evidence graph {full_mf.graph_nodes} nodes / {full_mf.graph_edges} edges"
    )
    if full_mf.failure_modes:
        st.error("Adversarial findings: " + " · ".join(full_mf.failure_modes))

st.markdown("## 5. Executable synthetic website swarm")
st.caption(
    "Unlike the planner above, this runs Streamlit AppTest with multiple synthetic personas. "
    "Only allow-listed research pages/actions are exercised; live trading, brokers and OpenAlgo are never clicked."
)
wa, wb, wc = st.columns(3)
web_agents = wa.slider("Website agents", 2, 8, 4, key="web_swarm_agents")
web_pages = wb.slider("Pages per agent", 2, 6, 4, key="web_swarm_pages")
web_rounds = wc.slider("Safe action rounds", 1, 3, 1, key="web_swarm_rounds")
if st.button("🕸️ Run synthetic website swarm", type="primary", width="stretch"):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with st.spinner("Synthetic users are navigating and stress-testing research pages…"):
        st.session_state["website_swarm"] = run_website_swarm(
            root, agents=web_agents, max_pages=web_pages, action_rounds=web_rounds, timeout=20
        )

web_report = st.session_state.get("website_swarm")
if web_report:
    x, y, z, w = st.columns(4)
    x.metric("Journeys", web_report.journeys_tested)
    y.metric("Page pass rate", f"{web_report.pass_rate:.1f}%")
    z.metric("Action success", f"{web_report.action_success_rate:.1f}%")
    w.metric("Safety violations", len(web_report.safety_violations))
    st.dataframe(
        [{
            "agent": j.agent_id,
            "persona": j.persona,
            "page": j.page,
            "loaded": j.loaded,
            "errors": "; ".join(j.visible_errors)[:180],
            "actions": f"{j.actions_completed}/{j.actions_attempted}",
            "time ms": round(j.duration_ms),
        } for j in web_report.journeys],
        width="stretch", hide_index=True,
    )
    if web_report.repeated_failures:
        st.error("Repeated website failures: " + " · ".join(web_report.repeated_failures))
    else:
        st.success("No repeated website failure pattern was found in this swarm run.")
    for finding in web_report.findings:
        st.write("• " + finding)

st.markdown("## 3. Synthetic website journeys")
st.caption(
    "The planner is allow-listed. The next QA layer can execute these plans with Streamlit "
    "AppTest and record UI exceptions, visible errors and repeated failures."
)
st.dataframe(
    [
        {
            "persona": p.name.replace("_", " ").title(),
            "planned safe pages": " → ".join(plan_journey(p)),
        }
        for p in PERSONAS
    ],
    width="stretch",
    hide_index=True,
)
st.caption("Allowed journey pages: " + ", ".join(SAFE_WEB_PAGES))
ui.footer_note("Research only · synthetic agents · fake markets · no broker execution")
