"""Upstox Sandbox page: API testing without live orders."""
import os

import streamlit as st

from algobot import ui
from algobot.config import ConfigError, load_config, validate_config
from algobot.live_data import INTERVALS, MARKETS, LiveDataError, fetch_ohlc
from algobot.paper_trading import evaluate, split_open_and_closed
from algobot.upstox_bod_instruments import UpstoxBODResolver
from algobot.upstox_sandbox import (
    UpstoxSandboxClient,
    UpstoxSandboxError,
    clean_token,
    extract_order_id,
    sandbox_token,
    token_preview,
)

SIDE_KEY = "upstox_sandbox_side"

ui.setup("Upstox Sandbox", "🧪")
ui.header(
    "Upstox Sandbox",
    "Connect the private sandbox token, test the order lifecycle, and keep live trading completely separate.",
    mode="execution:Sandbox",
)

st.info(
    "🟢 SANDBOX ONLY · This page uses Upstox's sandbox endpoint. "
    "No live Upstox endpoint or live credential is used."
)

# Prefer the process environment, then Streamlit Secrets. Never display the token.
token = sandbox_token()
token_source = "environment" if token else ""
if not token:
    try:
        secret_value = st.secrets.get("UPSTOX_SANDBOX_ACCESS_TOKEN")
        token = clean_token(secret_value)
        token_source = "Streamlit Secrets" if token else ""
    except Exception:
        token = None

if token:
    st.success(f"✅ Sandbox token detected privately ({token_source}). Token value is never shown.")
    st.caption(
        f"Preview: `{token_preview(token)}` — check this matches the token's length/prefix "
        "shown on the Upstox sandbox app page. A 401 despite 'detected' almost always means "
        "this string is technically present but wrong."
    )
    with st.expander("Still getting 401 Unauthorized? Check these in order"):
        st.markdown(
            "1. **Wrong kind of token.** A sandbox 401 usually means a *live* Upstox "
            "access token (from the normal OAuth login flow) was pasted here. Sandbox "
            "calls only accept a token generated from the **Sandbox** section of "
            "[your Upstox app](https://account.upstox.com/developer/apps) — open the "
            "sandbox app there and click **Generate** to get a sandbox-only token.\n"
            "2. **Expired token.** Upstox sandbox tokens are valid for 30 days only, "
            "with no refresh — generate a new one if it's older than that.\n"
            "3. **Secrets not reloaded.** On Streamlit Community Cloud, saving a secret "
            "does not hot-reload the running app — reboot the app from the Streamlit "
            "dashboard (Manage app → ⋮ → Reboot) after editing secrets.\n"
            "4. **Pasted with quotes/`Bearer `/newline.** e.g. "
            '`UPSTOX_SANDBOX_ACCESS_TOKEN = "eyJ...\\n"` in `secrets.toml`. This app now '
            "strips quotes, a leading `Bearer `, and surrounding whitespace automatically, "
            "so if the preview above still looks off, re-copy the token fresh from Upstox.\n"
            "5. **Different Upstox app / API key.** The sandbox token is tied to the "
            "specific sandbox app it was generated under — confirm you generated it under "
            "the same app whose sandbox mode you're testing, not a separate live app."
        )
else:
    st.warning(
        "No sandbox token detected. Add UPSTOX_SANDBOX_ACCESS_TOKEN to Streamlit Secrets "
        "and refresh the app."
    )

st.markdown("### 1. Sandbox setup")
st.markdown(
    "Upstox sandbox tokens are intended for sandbox orders only. "
    "Upstox currently documents sandbox order placement, modification, and cancellation."
)
st.markdown(
    "[Open the official Upstox Sandbox documentation]"
    "(https://upstox.com/developer/api-documentation/sandbox/)"
)
st.caption(
    "Upstox says sandbox access tokens are valid for 30 days. "
    "Keep the token private and never commit it to GitHub or paste it into chat."
)

st.divider()
st.markdown("### 2. Strategy signal (suggestion only)")
st.caption(
    "Runs your saved, deterministic strategy (the same demo/rules engine as Backtest and "
    "Paper Trading) against real, delayed prices and shows what it is currently doing. "
    "This never places, modifies, or cancels anything -- at most it offers to fill in the "
    "Side field in the order form below, which you still review and confirm yourself."
)

_demo_path = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "configs", "demo_rules.yaml"
)
_raw = st.session_state.get("last_raw")
signal_cfg = None
try:
    if _raw is not None:
        signal_cfg = validate_config(_raw)
        st.caption("Using the strategy from your last Backtest.")
    else:
        signal_cfg = load_config(_demo_path)
        st.caption("Using the demo strategy. Run a Backtest first to check your own strategy here.")
except ConfigError as exc:
    st.warning(f"Could not load a strategy to check: {exc}")

sig_c1, sig_c2 = st.columns(2)
signal_symbol_label = sig_c1.selectbox("Market", list(MARKETS), key="sandbox_signal_symbol")
signal_interval_label = sig_c2.selectbox(
    "Timeframe", list(INTERVALS), index=1, key="sandbox_signal_interval"
)

if signal_cfg is not None and st.button("Check current signal", key="sandbox_check_signal"):
    try:
        _ticker = MARKETS[signal_symbol_label]
        _yf_interval, _yf_period = INTERVALS[signal_interval_label]
        _signal_df = fetch_ohlc(_ticker, _yf_interval, _yf_period)
        _result = evaluate(signal_cfg, _signal_df)
        st.session_state["sandbox_signal_snapshot"], _ = split_open_and_closed(_result)
    except LiveDataError as exc:
        st.error(str(exc))
        st.session_state["sandbox_signal_snapshot"] = None

_snapshot = st.session_state.get("sandbox_signal_snapshot")
if _snapshot:
    _side = _snapshot["side"]
    _suggested = "BUY" if _side == "LONG" else "SELL"
    st.markdown(
        ui.card(
            f"Strategy is currently {_side}",
            f"Entered at {_snapshot['entry_price']:.2f} on {_snapshot['entry_time']}. "
            "This comes from delayed data, not a live quote -- check the real price before acting on it.",
            "🟢" if _side == "LONG" else "🔴",
        ),
        unsafe_allow_html=True,
    )
    if st.button(f"Prefill Side = {_suggested} below", key="sandbox_use_signal"):
        st.session_state[SIDE_KEY] = _suggested
        st.rerun()
elif "sandbox_signal_snapshot" in st.session_state and _snapshot is None:
    st.caption("Strategy is flat right now -- no open signal to suggest.")

st.divider()
st.markdown("### 3. Select the sandbox instrument")
st.caption(
    "TradeALGO can resolve the exact NIFTY CE/PE instrument key from Upstox's published NSE "
    "instrument file. This lookup is read-only; the selected key is only passed to the sandbox order form."
)

resolver = UpstoxBODResolver()
instrument_token = ""
instrument_ref = None

try:
    @st.cache_data(ttl=300, show_spinner=False)
    def _nifty_option_expiries():
        return UpstoxBODResolver().expiries()

    expiries = _nifty_option_expiries()
except ConfigError as exc:
    expiries = []
    st.error(str(exc))

if expiries:
    i1, i2, i3 = st.columns(3)
    with i1:
        sandbox_option_type = st.selectbox("Option", ["CE", "PE"], key="sandbox_option_type")
    with i2:
        sandbox_expiry = st.selectbox("Expiry", expiries, key="sandbox_option_expiry")
    try:
        @st.cache_data(ttl=300, show_spinner=False)
        def _nifty_option_contracts(option_type, expiry):
            return UpstoxBODResolver().find_options(option_type, expiry)

        contracts = _nifty_option_contracts(sandbox_option_type, sandbox_expiry)
    except ConfigError as exc:
        contracts = []
        st.error(str(exc))

    if contracts:
        strikes = [float(c.strike_price) for c in contracts if c.strike_price is not None]
        with i3:
            selected_strike = st.selectbox(
                "Strike",
                strikes,
                format_func=lambda x: f"{x:g}",
                key="sandbox_option_strike",
            )
        selected = next((c for c in contracts if c.strike_price == float(selected_strike)), None)
        if selected:
            instrument_ref = selected
            instrument_token = selected.instrument_key
            st.success(
                f"Resolved: **{selected.trading_symbol}** · {selected.instrument_key} · "
                f"lot size {selected.lot_size or 'n/a'}"
            )
            st.caption("The instrument token below is filled automatically from Upstox BOD data.")
    else:
        st.warning("No NIFTY contracts were found for the selected option type and expiry.")
else:
    st.warning("Could not load current NIFTY option contracts. You can use manual token entry below.")

manual_token = st.checkbox(
    "Enter an instrument token manually",
    value=False,
    key="sandbox_manual_token",
)
if manual_token:
    instrument_token = st.text_input(
        "Instrument token",
        value=instrument_token,
        placeholder="Example: NSE_FO|...",
        help="Use the exact instrument_key/instrument_token supplied by Upstox for the contract you are testing.",
        key="sandbox_manual_instrument_token",
    )

with st.form("upstox_sandbox_order"):
    c1, c2 = st.columns(2)
    with c1:
        quantity = st.number_input("Quantity", min_value=1, value=1, step=1)
        transaction_type = st.selectbox("Side", ["BUY", "SELL"], key=SIDE_KEY)
        product = st.selectbox("Product", ["D", "I", "MTF"], index=0)
    with c2:
        order_type = st.selectbox("Order type", ["MARKET", "LIMIT", "SL", "SL-M"])
        validity = st.selectbox("Validity", ["DAY", "IOC"])
        disclosed_quantity = st.number_input(
            "Disclosed quantity", min_value=0, value=0, step=1
        )

    price = 0.0
    trigger_price = 0.0
    if order_type in {"LIMIT", "SL"}:
        price = st.number_input(
            "Price", min_value=0.0, value=0.0, step=0.05,
            help="Required for LIMIT and SL orders.",
        )
    if order_type in {"SL", "SL-M"}:
        trigger_price = st.number_input(
            "Trigger price", min_value=0.0, value=0.0, step=0.05,
            help="Required for SL and SL-M orders.",
        )

    confirm = st.checkbox(
        "I confirm this sends an order to UPSTOX SANDBOX ONLY, not live Upstox."
    )
    send = st.form_submit_button("🧪 Send sandbox order", type="primary")

if send:
    if not confirm:
        st.error("Tick the sandbox confirmation first.")
    elif not token:
        st.error("No sandbox token is configured.")
    elif not instrument_token.strip():
        st.error("Enter the Upstox instrument token.")
    else:
        preview = {
            "instrument_token": instrument_token.strip(),
            "quantity": int(quantity),
            "transaction_type": transaction_type,
            "order_type": order_type,
            "product": product,
            "validity": validity,
            "price": float(price),
            "trigger_price": float(trigger_price),
            "disclosed_quantity": int(disclosed_quantity),
            "environment": "UPSTOX SANDBOX",
        }
        st.markdown("**Order preview**")
        st.json(preview)
        try:
            response = UpstoxSandboxClient(token=token).place_order(
                instrument_token=instrument_token,
                quantity=int(quantity),
                transaction_type=transaction_type,
                order_type=order_type,
                product=product,
                validity=validity,
                price=float(price),
                trigger_price=float(trigger_price),
                disclosed_quantity=int(disclosed_quantity),
            )
            st.success("Sandbox order request accepted by Upstox.")
            st.json(response)
            order_id = extract_order_id(response)
            if order_id:
                st.session_state["upstox_sandbox_order_id"] = order_id
                st.code(order_id, language="text")
        except UpstoxSandboxError as exc:
            st.error(str(exc))

st.divider()
st.markdown("### 4. Modify or cancel the last sandbox order")
last_order = st.session_state.get("upstox_sandbox_order_id")
if last_order:
    st.code(last_order, language="text")
    m1, m2 = st.columns(2)
    with m1:
        modify_confirm = st.checkbox(
            "Confirm sandbox modification",
            key="sandbox_modify_confirm",
        )
        if st.button("Modify last sandbox order", disabled=not modify_confirm):
            try:
                response = UpstoxSandboxClient(token=token).modify_order(
                    last_order,
                    int(quantity),
                    price=float(price),
                    order_type=order_type,
                    trigger_price=float(trigger_price),
                    validity=validity,
                    disclosed_quantity=int(disclosed_quantity),
                )
                st.success("Sandbox modify request accepted.")
                st.json(response)
            except UpstoxSandboxError as exc:
                st.error(str(exc))
    with m2:
        cancel_confirm = st.checkbox(
            "Confirm sandbox cancellation",
            key="sandbox_cancel_confirm",
        )
        if st.button("Cancel last sandbox order", disabled=not cancel_confirm):
            try:
                response = UpstoxSandboxClient(token=token).cancel_order(last_order)
                st.success("Sandbox cancel request accepted.")
                st.json(response)
            except UpstoxSandboxError as exc:
                st.error(str(exc))
else:
    st.caption("Place a sandbox order first; its order ID will appear here.")

st.divider()
st.markdown("### 5. What we are testing")
ui.check_row(
    "PASS",
    "Sandbox endpoint only",
    "The client uses Upstox's official SDK with Configuration(sandbox=True); there is no live-host switch.",
)
ui.check_row(
    "PASS",
    "Private token",
    "The token is read from the environment or Streamlit Secrets and is never displayed.",
)
ui.check_row(
    "PASS",
    "Explicit confirmation",
    "Place, modify, and cancel actions require a separate user confirmation.",
)
ui.check_row(
    "PASS",
    "Existing risk controls untouched",
    "This sandbox page is separate from the existing risk manager and live-trading lock.",
)
ui.check_row(
    "PASS",
    "Strategy-to-order wiring",
    "Section 2 runs the same deterministic strategy engine as Backtest/Paper Trading on delayed "
    "prices and can prefill the Side field only; it cannot submit by itself. Instrument token, "
    "quantity, order type and the sandbox confirmation checkbox are still entered/ticked by hand "
    "for every order.",
)
ui.workflow_nav("sandbox", complete=bool(token))
ui.footer_note("Upstox Sandbox only. No live orders. Keep the sandbox token private.")
